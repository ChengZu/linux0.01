
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc,char* argv[])
{
	if(argc != 2)
	printf("Usage:  filename\n");
	if(unlink(argv[1])!=0)
	printf("unlink"),exit(-1);
	printf("unlink %s success!\n",argv[1]);
	return 0;
}

