#include <string.h>
#include <sys/types.h>
#include <unistd.h>

char *program_name;

void usage (int status)
{
	if (status != 0)
		printf ("Try `%s --help' for more information.\n", program_name);
	else
	{
		printf ("\
Usage: %s [OPTION]... FILE...\n", program_name);
		printf ("\
Remove (unlink) the FILE(s).\n\
\n\
  -d, --directory       unlink FILE, even if it is a non-empty directory\n\
  -r, -R, --recursive   remove the contents of directories recursively\n\
  -h, --help            show help information\n\
");

      printf ("\
\n\
To remove a file whose name starts with a `-', for example `-foo',\n\
use one of these commands:\n\
  %s -- -foo\n\
\n\
  %s ./-foo\n\
",
		program_name, program_name);
	printf ("\
\n\
Note that if you use rm to remove a file, it is usually possible to recover\n\
the contents of that file.  If you want more assurance that the contents are\n\
truly unrecoverable, consider using shred.\n\
");
    }
  exit (status);
}

struct rm_options
{
  unsigned short unlink_dirs;
  unsigned short ignore_missing_files;
  unsigned short interactive;
  unsigned short recursive;
  unsigned short stdin_tty;
  unsigned short verbose;
};
struct rm_options x;
static int offset = 1;
int res,argchar;

int getopt_long(char* argv)
{
	if(*argv != '-')
	{
		return -1;
	}
	
	res = *(argv + offset);
	if(res == '\0')
	{
		return -1;
	}
	offset++;
	return res;
}

static void rm_option_init (struct rm_options *x, char* argv)
{
	x->unlink_dirs = 0;
	x->ignore_missing_files = 0;
	x->interactive = 0;
	x->recursive = 0;
	x->stdin_tty = 0;
	x->verbose = 0;

	while ((argchar = getopt_long (argv)) != -1)
	{
	switch (argchar)
	{
		case 0:		/* Long option.  */
			break;
		case 'd':
			x->unlink_dirs = 1;
			break;
		case 'f':
			x->interactive = 0;
			x->ignore_missing_files = 1;
			break;
		case 'i':
			x->interactive = 1;
			x->ignore_missing_files = 0;
			break;
		case 'r':
		case 'R':
			x->recursive = 1;
			break;
		case 257:
			x->stdin_tty = 1;
			break;
		case 'v':
			x->verbose = 1;
			break;
		case 'h':
			usage (0);
			break;

		default:
	  		usage (-1);
		}
	}

}
int remove(struct rm_options *x,char * name)
{
	res = unlink(name);
	if(res == 0) exit(0);
	if(!(x->recursive  || x->unlink_dirs))
		printf("ERROR:%d\n", res),exit(-1);

	res = rmdir(name);
	if(res == 0) exit(0);

	printf("ERROR:%d\n", res),exit(-1);
}

int main(int argc,char* argv[])
{
	program_name = argv[0];
	if(argc < 2 || argc > 3)
		usage (-1);
	if(!strcmp(argv[1] , "--help"))
		usage (0);


	rm_option_init (&x,argv[1]);
	remove(&x, argv[argc-1]);

	return 0;
}



