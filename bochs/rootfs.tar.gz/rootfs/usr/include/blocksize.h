#ifndef _BLOCK_SIZE_H
#define _BLOCK_SIZE_H

#define BLOCK_SIZE 1024		/* file system data block size */

#endif /* _BLOCK_SIZE_H */
